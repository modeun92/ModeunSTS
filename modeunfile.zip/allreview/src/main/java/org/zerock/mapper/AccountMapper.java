package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.AccountVO;

public interface AccountMapper {
	
	public AccountVO getById(String id);
	
	public int idCheck(String id);
	
	public int loginCheck(AccountVO account);
	
	public int changePw(AccountVO account, String renewPw);
	
	public int deleteAccount(AccountVO account);
	
	public List<AccountVO> getListAccount();
	
	public int insert(AccountVO account);
}
