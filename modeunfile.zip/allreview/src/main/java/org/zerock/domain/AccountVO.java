package org.zerock.domain;

import lombok.Data;

@Data
public class AccountVO {
	private String id;
	private String pw;
}
