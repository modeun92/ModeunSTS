package org.zerock.service;

import org.zerock.domain.AccountVO;

public interface AccountService {
	public int register(AccountVO account);
	
	public int changePw(AccountVO account, String renewPw);
	
	public int deleteAccount(AccountVO account);
	
	public int login(AccountVO account);
	
	public int checkID(String id);
}
