package org.zerock.service;

import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.stereotype.Service;
import org.zerock.domain.AccountVO;
import org.zerock.mapper.AccountMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@AllArgsConstructor
@Log4j
public class AccountServiceImpl implements AccountService{
	
	private AccountMapper mapper;

	@Override
	public int register(AccountVO account) {
		// TODO Auto-generated method stub
		log.info("account register...." + account);
		int value;
		try {
			value = mapper.insert(account);
		} catch(Exception e) {
			value = 0;
		}
		return value;
	}

	@Override
	public int changePw(AccountVO account, String renewPw) {
		// TODO Auto-generated method stub
		log.info("account changePassword...." + account + renewPw);
		return mapper.changePw(account, renewPw);
	}

	@Override
	public int deleteAccount(AccountVO account) {
		// TODO Auto-generated method stub
		log.info("account delete...." + account);
		return mapper.deleteAccount(account);
	}

	@Override
	public int login(AccountVO account) {
		// TODO Auto-generated method stub
		log.info("account login...." + account);
		return mapper.loginCheck(account);
	}

	@Override
	public int checkID(String id) {
		// TODO Auto-generated method stub
		log.info("account cheking id" + id);
		return mapper.idCheck(id);
	}
}
