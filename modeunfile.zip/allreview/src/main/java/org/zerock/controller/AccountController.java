package org.zerock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.zerock.domain.AccountVO;
import org.zerock.service.AccountService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RestController
@RequestMapping("/account")
@AllArgsConstructor
@Log4j
public class AccountController {
	private AccountService service;
	
	@RequestMapping(method = { RequestMethod.POST,
			RequestMethod.PATCH }, value = "/login", 
			consumes = "application/json", produces = {
					MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> login(@RequestBody AccountVO account, HttpSession session) {
		log.info("controller login...." + account);
		if (service.login(account) == 1) {
			session.setAttribute("logioCheck", "in");
			session.setAttribute("account", account);
			return new ResponseEntity<>("success", HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
	
	@RequestMapping(method = { RequestMethod.POST,
			RequestMethod.PATCH }, value = "/idCheck", 
			consumes = "application/json", produces = {
					MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> idCheck(@RequestBody String id) {
		log.info("controller idCheck...." + id);
		return service.checkID(id) == 1
				? new ResponseEntity<>("success", HttpStatus.OK) 
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@RequestMapping(method = { RequestMethod.POST,
			RequestMethod.PATCH }, value = "/changePw", 
			consumes = "application/json", produces = {
					MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> changePw(
			@RequestBody AccountVO account, String renewPw) {
		log.info("controller changePw...." + account + renewPw);
		return service.changePw(account, renewPw) == 1
				? new ResponseEntity<>("success", HttpStatus.OK) 
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@RequestMapping(method = { RequestMethod.POST,
			RequestMethod.PATCH }, value = "/deleteAccount", 
			consumes = "application/json", produces = {
					MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> deleteAccount(
			@RequestBody AccountVO account) {
		log.info("controller deleteAccount...." + account);
		return service.deleteAccount(account) == 1
				? new ResponseEntity<>("success", HttpStatus.OK) 
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@RequestMapping(method = { RequestMethod.POST}, value = "/register", 
			consumes = "application/json", produces = {
					MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> register(
			@RequestBody AccountVO account, String rePw) {
		log.info("controller register...." + account);
		if (rePw != account.getPw()) {
			new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		int value = service.register(account);
		return  value == 1
				?new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
}
