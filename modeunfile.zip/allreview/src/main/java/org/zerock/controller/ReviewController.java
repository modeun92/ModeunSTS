package org.zerock.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lombok.AllArgsConstructor;
import lombok.extern.java.Log;

@Controller
@RequestMapping("/review")
@Log
@AllArgsConstructor
public class ReviewController {
	
	
	@GetMapping(value="/reg")
	public String reviewRegGet() {
		log.info("review regist get");
		return "review/reviewReg";
	}
	
	@PostMapping(value="/reg")
	public String reviewRegPost() {
		log.info("review regist post");
		return "review/reviewList";
	}
	
	
	@RequestMapping(value="/search", method = RequestMethod.GET)
	public String reviewSearch() {
		log.info("review search");
		return "review/reviewSearch";
	}
	
	@RequestMapping(value="/modify", method = RequestMethod.GET)
	public String reviewModify() {
		log.info("review modify");
		return "review/reviewModify";
	}

	@RequestMapping(value="/list", method = RequestMethod.GET)
	public String reviewList() {
		log.info("review list");
		return "review/reviewList";
	}
	
	
}
