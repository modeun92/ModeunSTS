package org.zerock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/profile")
@AllArgsConstructor
public class ProfileController {

	@GetMapping(value="/logout")
	public String logout(HttpSession session) {
		log.info("logout..");
		session.setAttribute("logioCheck", null);
		session.setAttribute("account", null);
		return "/board/list";
	}
	
	@GetMapping("/login")
	public void login() {
		log.info("login..");
	}
	
	@PostMapping("/userProfile")
	public void userProfile() {
		log.info("userProfile..");
	}
}
